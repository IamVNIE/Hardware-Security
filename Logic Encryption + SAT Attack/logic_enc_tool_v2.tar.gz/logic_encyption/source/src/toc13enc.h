#ifndef _TOC_13_ENC_H_DEFINED_
#define _TOC_13_ENC_H_DEFINED_

#include <vector>
#include "ckt.h"
#include "ast.h"
#include "node.h"
#include "sim.h"


namespace ckt_n
{
    class toc13enc_t
    {
    public:
	typedef std::pair<std::string, bool> cube_pair;
	typedef std::pair<int, int> index_pair;
	ckt_n::nodelist_t and_list, not_list, rest_andlist;
	std::string basefile;
    protected:
        ckt_t ckt;
	double fraction;

        std::vector<bool_vec_t> input_sims;
        std::vector<bool_vec_t> output_sims;
        std::vector<int> onesCount;
        std::vector<double> faultMetrics;
        std::vector<bool> key_values;

        std::vector<int> marks;
	
	//yasin
	ckt_n::ckt_t* ckt_old;
	//ckt_n::ckt_t* ckt_new;
	std::vector<int> slice_cktinp_indices;
	std::vector<int> slice_keyinp_indices, sliceSlice_keyinp_indices;// 2nd one within the slice, first one for th whle circuit
	std::vector<int> ckt_keyinp_indices, ckt_cktinp_indices, sliceSlice_cktinp_indices;
   	std::vector<bool> key_vector;
    public:
        toc13enc_t(ast_n::statements_t& stms, double fr)
            : ckt(stms)
            , fraction(fr)
        {
        }
        void evaluateFaultImpact(int nSims);
        void readFaultImpact(const std::string& fault_impact_file);
        void encodeXORs();
        void ttlock(std::string cube_file);
        void sfll(std::string cube_file);
  	bool is_excludable(int i, std::vector<cube_pair> cube_all[]);
        void store_sol (std::string fname);
	void add_notlist(); 
	void include_cube(node_t *or_gate, node_t *and_gate, cube_pair &cube_orig);
	void exclude_cube(node_t *or_gate, node_t *and_gate, cube_pair &cube_orig);
	int compute_cost(std::string filename, bool init);
	int find_index(nodelist_t list, node_t *);
	node_t* get_by_name(nodelist_t list, std::string name);
	void init_sol(node_t *or_gate, std::vector<cube_pair> &cube_orig, bool is_ttlock);
	void init_andlist(ckt_n::nodelist_t &not_list, ckt_n::nodelist_t &and_list, std::vector<cube_pair> cube_orig);
        node_t* init_BigAND(cube_pair &cube_orig, int i);
        index_pair neighbor(node_t *or_gate, std::vector<cube_pair> &cube_orig, std::vector<cube_pair> cube_all[]);
	void init_cam(std::vector<std::string> &cam, int size);
	void print_cam_to_file(std::vector<std::string> cam, std::vector<cube_pair> cube_orig);
	void print_verilog();
	void lock_ckt(std::vector<cube_pair> cube_orig, std::vector<std::string> cam);
	void encodeMuxes();
        void encodeIOLTS14();
        void write(std::ostream& out);
    private:
        // reformat the vector of probabilities into a map (indices will change during encryption.)
        void _convert_node_prob(std::vector<double>& ps, std::map<std::string, double>& pmap);
        double _get_prob(std::map<std::string, double>& pmap, node_t* n);

        void _dpaKeySA(long long nSims); //dpa key gate position by SA
	void _replaceKeyGate(); //replace key gate
	long long _evaluateRandomVectorWithKey(long long nSims);
	void _evaluateRandomVectors(int nSims);
        double _evaluateFaultImpact(node_t* n);
        void _set_assumps(sat_n::vec_lit_t& assumps,
            ckt_n::index2lit_map_t& lmap,
            const bool_vec_t& inputs,
            node_t* n,
            int fault);
        void _extract_outputs(
            sat_n::Solver& S,
            ckt_n::index2lit_map_t& lmap,
            bool_vec_t& outputs
        );
        node_t* _get_best_other(node_t* n1, node_t* kg, std::map<std::string, double>& ps);
        int _count_differing_outputs(
            const bool_vec_t& sim_out, const bool_vec_t& err_out);
    };
}

#endif


// end of the file.
// 
//
//
