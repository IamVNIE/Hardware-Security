#ifndef _LCMP_H_DEFINED_
#define _LCMP_H_DEFINED_

int lcmp_main(int argc, char* argv[]);

#endif
