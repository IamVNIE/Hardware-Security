#PBS -l walltime=36:00:00
cd /home/vin/Desktop/logic_enc/logicEnc/logic_encyption/source/src
./sle -r1 -f0.05 ../../benchmarks/original/ex1010.bench >& myTest/ex1010_enc05.bench
