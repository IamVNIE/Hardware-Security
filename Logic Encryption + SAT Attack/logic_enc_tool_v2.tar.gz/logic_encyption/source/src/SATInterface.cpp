#include "SATInterface.h"

namespace sat_n {
#ifndef CMSAT
    const lbool l_True(lbool::p_True);
    const lbool l_False(lbool::p_False);
    const lbool l_Undef(lbool::p_Undef);
#endif
}
