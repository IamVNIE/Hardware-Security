import os
import sys
def main(argc, argv):
	fi = sys.argv[1]
	#fo = sys.argv[2]
	cmd = '~/alanmi-abc-6b74de13c57f/ -c " read_bench ' + fi + ' ; write_verilog ' + fi + '.v; " '
	print cmd, 'cmd'
	os.system (cmd)

