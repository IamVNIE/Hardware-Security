import os

import os
import sys 
import pickle 
import numpy as np 

import pickle 

def parse_area_file(filename) : #(bm_name, iteration):
	area = 0
	try:
		with open(filename) as fp:
			data = fp.readlines()
			for line in data:
				if (line.find('total') != -1):
						temp = line.strip().split()				
						#print temp , temp[1], temp[2] 
						return float(temp[2])	
	except IOError as e:
		print filename , 'not found'
	return area 
	
def parse_power_file(filename, bm_name) : #(bm_name, iteration):
	power = -1
	#fname = filename.split('/')[-1]
	#print fname
	#filename =	filename + '_RTL_power.rep' #'../../Data/'+ bm_name + '/build/iteration'+str(iteration)+ '_RTL_power.rep'
	#print filename , ' , ' , bm_name
	try:
			with open(filename) as fp:
				data = fp.readlines()
				for line in data:
					if (line.startswith(bm_name)):
							temp = line.strip().split()
							#print temp #, temp[1], temp[4] 
							return float(temp[4])
	except IOError as e:
				print filename , 'not found'  
	return power

def parse_delay_file(filename) : # (bm_name, iteration):
		delay = 0
		try:
		 	with open(filename) as fp:
				data = fp.readlines()
				for line in data:
						if (line.startswith('Timing')):
								temp = line.strip().split()
								#print temp #, temp[1], temp[4]
								slack = int(temp[3][:-2])
								delay =	 1000 - slack
								#print delay
								return float(delay)
		except IOError as e:
				print filename , 'not found'
		return delay

def apd_given_file (base_file_name): # base filename includes directory
 	area_fname = base_file_name + '_RTL' + '_cell.rep'
 	area =  parse_area_file(area_fname)  
	
	# B. power 
	power_fname = base_file_name + '_RTL' + '_power.rep'
	power =  parse_power_file(power_fname, bm_name)
	  
	# C. delay 
	delay_fname = base_file_name + '_RTL' + '_timing.rep'
	delay =  parse_delay_file(delay_fname)	
	
	return 	area, power, delay


#######################################################################

#benchmarks = [ 's13207', 'dalu']
#benchmarks = [ 's15850', 'lsu_excp']
#benchmarks = [ 's9234', 's38584']
#benchmarks = [ 'ifu_ifq', 'tlu_mmu']
#benchmarks = [ 'apex4', 'c432', 'c880', 'ex1010']
#benchmarks = [ 'ex5', 'fpu_div', 'fpu_in', 'i4']
#benchmarks = [ 'i7', 'i8', 'i9', 'ifu_dcl']
#benchmarks = [ 'k2', 'lsu_rw', 's298', 's35932']
benchmarks = [ 's400', 's444', 's5378', 's713']
#benchmarks = [ 'seq']
benchmarks = [ 'c432', 'apex4', 'dalu', 'c880', 'ex1010', 'ex5', 'fpu_div', 'fpu_in', 's713', 'i7'] 
#for i in [0]:

benchmarks  = ['i8', 'apex4', 's38584', 's444', 'tlu_mmu', 's400', 'i9', 'fpu_div', 's13207', 'ex1010', 's35932', 'ifu_dcl', 'dalu', 'c880', 's15850', 's9234', 'i4', 'seq', 'fpu_in', 'ex5', 's713', 'i7', 'lsu_excp', 's5378', 'lsu_rw', 'ifu_ifq', 'k2', 's298', 'c432']
area_ov = [] 
power_ov = [] 
delay_ov = [] 
aaa = [] 
ddd = [] 
ppp = [] 
apd = []

for it in benchmarks:
	print it, 

print '\n\n'


## benchmarks = [ 'c432', 'apex4', 'dalu', 'c880', 'ex1010', 'ex5', 'fpu_div', 'fpu_in']
       
benchmarks = [ 'c432', 'apex4', 'dalu', 'c880', 'ex1010', 'ex5', 'fpu_div', 'fpu_in', 's713', 'i7']
for num_minterms in [16, 32, 64]:
 for i in xrange (0, len(benchmarks)):
	orig_filename = "../Results/" + benchmarks [i]  +  '/build/' +  benchmarks [i] 
	print orig_filename
	bm_name = benchmarks [i]
	area_orig , power_orig, delay_orig = apd_given_file (orig_filename)
	
	print orig_filename," : " , area_orig , power_orig, delay_orig

	#for num_minterms in [32]:
	#for num_minterms in [16, 32, 64]:
    	for s in [32]:
                        #bm_name =  benchmarks[i]
                	v_name = bm_name+"_"+str(s)+"_"+str(num_minterms) + "_clean"

			n_name = bm_name+"."+str(s)+"_"+str(num_minterms)
			cmd = "./sle -t -f 0.2 -T " + n_name + " " + bm_name+".bench &"

			print cmd 
			os.system (cmd ) 
			continue 


			area_withSEJI, power_withSEJI, delay_withSEJI = apd_given_file (final_filename)
			print area_withSEJI, power_withSEJI, power_withSEJI
			if area_withSEJI == 0:
				area_withSEJI = 1e16
				area_ov.append ('NA')
				power_ov.append ('NA')
				delay_ov.append ('NA')   					
			else:
				aov = (area_withSEJI-area_orig)/area_orig*100
				pov = (power_withSEJI-power_orig)/power_orig*100
				dov = (delay_withSEJI-delay_orig)/delay_orig*100
				area_ov.append (str(round (aov, 1) ) )
				power_ov.append (str( round ( pov, 1) ) )
				delay_ov.append (str( round (dov, 1) ) )
	      	
		 
			
#			print "next "	

 aaa.append (area_ov)
 ppp.append (power_ov)
 ddd.append (delay_ov) 
 area_ov = []
 power_ov = []
 delay_ov = []
 #print area_ov

s = 64
fname = 'apd_' + str(s) + '.pickle'
fn = open (fname, 'w') 
to_pic = [aaa, ppp, ddd]

pickle.dump (to_pic, fn) 

fn.close() 




print '\narea\n'
for item in aaa:
 for it in item:	
        print it, 
 print '' 
print '\npower \n'

for item in ppp:
 for it in item:
        print it,
 print ''
print '\ndelay\n'

for item in ddd:
 for it in item:
        print it,
 print ''
print '\n'

exit() 

print area_ov , '\n\n'
print power_ov , '\n\n'
print delay_ov , '\n\n'

for item in area_ov:
	print item, 
print '\n'

for item in power_ov:
        print item,
print '\n'

for item in delay_ov:
        print item,
print '\n'
			
			##cmd = "time ./a.out "+bm_name+".pla"+" "+v_name+"_clean"+" "+v_name+"_new > "+v_name+".log " ### " " + str()
               	 	##print cmd
                	#os.system (cmd  ) #+ ' & ')






##################
#@apd_mat_3d[0][key_no][i] = (area_withSEJI-area_orig)/area_orig*100
  #                      apd_mat_3d[1][key_no][i] = (power_withSEJI-power_orig)/power_orig*100
   #                     apd_mat_3d[2][key_no][i] = (delay_withSEJI-delay_orig)/delay_orig*100
