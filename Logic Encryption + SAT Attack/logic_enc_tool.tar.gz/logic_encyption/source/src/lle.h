#ifndef _LLE_H_DEFINED_
#define _LLE_H_DEFINED_

int lle_main(int argc, char* argv[]);
int lle_usage(const char* progname);

#endif
