#include "util.h"
#include "toc13enc.h"
#include <pthread.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include<algorithm>
#include<math.h>
#include<sstream>
#include<unistd.h>

extern int yyparse();
extern FILE* yyin;


namespace ckt_n
{
    void toc13enc_t::readFaultImpact(const std::string& fault_impact_file)
    {
        std::ifstream fin(fault_impact_file.c_str());
        //printf("Inside Fault Impact");

        std::string node_name;
        double fault_impact_metric;
        std::map<std::string, double> fault_impact_map;
        while((fin >> node_name >> fault_impact_metric)) {
            fault_impact_map[node_name] = fault_impact_metric;
        }

        if(ckt.num_nodes() != fault_impact_map.size()) {
            std::cerr << "Error: the fault impact file should have "
                      << ckt.num_nodes() << " values but it has "
                      << fault_impact_map.size() << " values instead."
                      << std::endl;
            exit(1);
        }
        faultMetrics.resize(ckt.num_nodes());
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            std::string name = ckt.nodes[i]->name;
            auto pos = fault_impact_map.find(name);
            if(pos == fault_impact_map.end()) {
                std::cerr << "Error: Unable to find node " << name 
                          << " in map. " << std::endl;
                exit(1);
            }
            faultMetrics[i] = pos->second;
        }
    }

    void toc13enc_t::evaluateFaultImpact(int nSims)
    {	
	//std::cout<<"\n"<<ckt.num_nodes();
	ckt.cleanup();
	//std::cout<<"\n"<<ckt.num_nodes();
        _evaluateRandomVectors(nSims);
        faultMetrics.resize(ckt.num_nodes());
        //printf("Inside evaluate Fault");
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            faultMetrics[i] = _evaluateFaultImpact(ckt.nodes[i]); // commented for testing, uncommnet later
        }
    }

    void toc13enc_t::_convert_node_prob(std::vector<double>& ps, std::map<std::string, double>& pmap)
    {
        //printf("Inside convert node prob");
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            assert(ckt.nodes[i]->get_index() == (int) i);
            const std::string& name = ckt.nodes[i]->name;
            assert(pmap.find(name) == pmap.end());
            pmap[name] = ps[i];
        }
    }

    void toc13enc_t::encodeIOLTS14()
    {
        //printf("Inside iolts14");
        int target_keys = (int) (fraction*ckt.num_nodes() + 0.5);
        std::vector<double> ps;
        ckt.compute_node_prob(ps);

        // convert to a map.
        std::map<std::string, double> pmap;
        _convert_node_prob(ps, pmap);

        // sort the probabilities according to the scheme in the paper.
        assert(ckt.num_nodes() == ps.size());
        typedef std::pair<double, node_t*> key_t;
        std::vector<key_t> candidates;
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            double pi = ps[i];
            assert(pi >= 0 && pi < (1 + 1e-10));
            if(pi > 1) pi = 1;
            double fi = 1-pi;
            double mi = std::min(pi, fi);
            key_t k(mi, ckt.nodes[i]);
            candidates.push_back(k);
        }

        std::sort(candidates.begin(), candidates.end());
        assert(target_keys < (int) candidates.size());
        for(int i=0; i != target_keys; i++) {
            node_t* n = candidates[i].second;
            double p = _get_prob(pmap, n);

            // decide whether to insert and or or.
            std::string func;
            int key;

            if(p > 0.5) {
                func = "and";
                key = 1;
            } else {
                func = "or";
                key = 0;
            }

            node_t* ki = ckt.create_key_input();
            key_values.push_back(key);
            ckt.insert_2inp_key_gate(ki, n, func);
        }
    }

    void toc13enc_t::encodeMuxes()
    {
        int target_keys = (int) (fraction*ckt.num_nodes() + 0.5);
        //printf("Encode with MUX");

        std::vector<double> ps;
        std::map<std::string, double> pmap;
        ckt.compute_node_prob(ps);
        _convert_node_prob(ps, pmap);

        typedef std::pair<double, int> double_int_pair_t;
        std::set<double_int_pair_t> metric_set;
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            double_int_pair_t p(faultMetrics[i], i);
            metric_set.insert(p);
        }
        key_values.clear();

        assert(target_keys < (int) ckt.num_nodes());//terminates if fails
        int cnt;
        nodeset_t nodes_to_insert;
        for(cnt=0; cnt < target_keys; cnt++) {
            // select the node.
            assert(metric_set.size() > 0);
            auto last = metric_set.rbegin();
            int index = last->second;
            assert(index >= 0 && index < (int) ckt.num_nodes());
            node_t* n = ckt.nodes[index];

            // get rid of this node now.
            double_int_pair_t p(*last);
            metric_set.erase(p);
            nodes_to_insert.insert(n);
        }
        for(auto it=nodes_to_insert.begin(); it != nodes_to_insert.end(); it++) {
            node_t* n = *it;

            // add the key now.
            node_t* ki = ckt.create_key_input();
            int val = rand() % 2;
            key_values.push_back(val ? true : false);
            node_t* kg = ckt.insert_mux_key_gate(ki, n);
            node_t* other = _get_best_other(n, kg, pmap);
            if(val == 1) {
                // mux input B is the node n.
                kg->inputs[1] = other;
                kg->inputs[2] = n;
            } else {
                // mux input A is the node n.
                kg->inputs[2] = other;
            }
            other->add_fanout(kg);
        }
        ckt.init_indices();
        ckt.topo_sort();
        ckt.cleanup();
    }

    double toc13enc_t::_get_prob(std::map<std::string, double>& pmap, node_t* n)
    {
        //printf("Inside get prob");
        auto pos = pmap.find(n->name);
        if(pos != pmap.end()) {
            return pos->second;
        } else {
            return -1;
        }
    }

    node_t* toc13enc_t::_get_best_other(node_t* n1, node_t* kg, std::map<std::string, double>& pmap)
    {
        //printf("Inside get best other");
        assert(kg->num_inputs() == 3);
        assert(kg->inputs[1] == n1);
        assert(kg->inputs[2] == NULL);

        double best_pr = 0;
        node_t* best_node = NULL;

        double p0 = _get_prob(pmap, n1);
        ckt.init_indices();

        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            node_t* ni = ckt.nodes[i];
            if(ni->is_keyinput()) continue;

            double pi = _get_prob(pmap, ni);
            if(pi == -1) continue;

            kg->inputs[2] = ni;
            if(ckt.has_cycle(marks)) continue;

            double pr_metric = p0*(1-pi) + pi*(1-p0);
            if(pr_metric > best_pr) {
                best_node = ni;
                best_pr = pr_metric;
            }
        }
        assert(best_node != NULL);
        return best_node;
    }

    void toc13enc_t::encodeXORs()
    {
        int target_keys = (int) (fraction*ckt.num_nodes() + 0.5);

        typedef std::pair<double, int> double_int_pair_t;
        std::set<double_int_pair_t> metric_set;
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            double_int_pair_t p(faultMetrics[i], i);
            metric_set.insert(p);
        }

        key_values.clear();

        assert(target_keys < (int) ckt.num_nodes());//terminates if fails
        int cnt;
        nodeset_t nodes_to_insert;
        for(cnt=0; cnt < target_keys; cnt++) {
            // select the node.
            assert(metric_set.size() > 0);
            auto last = metric_set.rbegin();
            int index = last->second;
            //int index = rand()%ckt.num_nodes();
            assert(index >= 0 && index < (int) ckt.num_nodes());
            node_t* n = ckt.nodes[index];

            // get rid of this node now.
            double_int_pair_t p(*last);
            metric_set.erase(p);
            // add to the set.
            nodes_to_insert.insert(n);
        }
	ckt.init_all_key_num();//initilize the total num keys
        for(auto it=nodes_to_insert.begin(); it != nodes_to_insert.end(); it++) {
            node_t* n = *it;
            // add the key now.
            node_t* ki = ckt.create_key_input();
            //int val = rand() % 2;
            int val = 0;			//make all key 0
            key_values.push_back(val ? true : false);
	    ki->keyval = val;
            ckt.insert_key_gate(n, ki, val);
        }
        ckt.topo_sort();
        ckt.cleanup();
	//_dpaKeySA(100);
	//std::cout<<"\n"<<_evaluateRandomVectorWithKey(100)<<"\n";
    }
/* ///             %%%%%%%%%%%%%%%%%%%%%55 TTLOCK %%%%%%%%% main  
    void toc13enc_t::ttlock(std::string filename){
	std::vector<cube_pair> cube_orig;
	std::string orig_benchname;
	for(int i=0; filename[i]!='.';i++)
		orig_benchname+=filename[i];
	basefile=filename;
	std::ifstream fi_cube(("cube/"+basefile+"_clean").c_str());
	
	if(fi_cube.fail()){
                std::cerr<<"file cube open failed"<<std::endl;
                exit(1);
        }
	std::string line_cube;

	srand (time(NULL) ) ;
	sleep (2);  
	
	while(!fi_cube.eof()){//read all the cubes
               getline(fi_cube, line_cube);
               cube_orig.push_back(cube_pair(line_cube, false));
        }
	cube_orig.erase(cube_orig.end());//delete EOF from list
	std::vector<std::string> cam;
	init_cam(cam, cube_orig.size());//init content addressable memory
	
	ckt_n::nodelist_t and_list_old;
	init_andlist(not_list, and_list, cube_orig);//create AND tree for each cube
	//create dummy XOR gate to initialize with constant ZERO output, feed it to the BIGOR gate
	std::string name = "zero";
	std::string func = "XOR";
	node_t* dummy_gate = node_t::create_gate(name, func);
	dummy_gate->add_input(ckt.inputs[0]);
	dummy_gate->add_input(ckt.inputs[0]);
	ckt.add_gate(dummy_gate);
	ckt.inputs[0]->add_fanout(dummy_gate);

	ckt_n::ckt_t::node_map_t ckt_nm;
	
	//randmoly choose a logic cone
	int i = rand()%ckt.outputs.size();
	//All signals for cubes must be OR before XOR with output
	std::ostringstream convert;
	convert<<i;
	name = "BigOR"+convert.str();
	func = "OR";
	node_t* or_gate = node_t::create_gate(name, func);
	ckt.add_gate(or_gate);
	or_gate->add_input(dummy_gate);
	or_gate->add_input(dummy_gate);
	dummy_gate->add_fanout(or_gate);
	node_t* op = ckt.outputs[i];
	name = op->name;
	op->output = false;
	ckt.outputs.erase(ckt.outputs.begin()+i);
	
	func = "XOR";
	node_t* xor_gate = node_t::create_gate(name, func);
	xor_gate->output = true;
	ckt.add_gate(xor_gate);
	
	ckt.outputs.insert(ckt.outputs.begin()+i, xor_gate);	
	
	op->name += "_old";
	or_gate->add_fanout(xor_gate);
	op->add_fanout(xor_gate);
	xor_gate->add_input(op);
	xor_gate->add_input(or_gate);

	//include all the cubes for ttlock
	for(unsigned j=0; j<cube_orig.size(); j++){
		//std::cout<<"cube_included "<<i<<std::endl;
		include_cube(or_gate, and_list[j], cube_orig[j]);
	}
	//update the cam
	for(unsigned c=0;c<cube_orig.size();c++){
        	if(cube_orig[c].second)
                        cam[c][i]='1';
                else    cam[c][i]='0';
        }
	print_cam_to_file(cam, cube_orig);
		
	store_sol("temp/"+basefile+".bench");
	//lock the netlist
	lock_ckt(cube_orig, cam);
	store_sol("temp/"+basefile+"_ttlock.bench");
    }*/

 ///             %%%%%%%%%%% TTLOCK %%%%%%%%% main  
    void toc13enc_t::ttlock(std::string filename){
	std::vector<cube_pair> cube_orig, cube_new[1000];
	std::string orig_benchname;
	for(int i=0; filename[i]!='.';i++)
		orig_benchname+=filename[i];
	basefile=filename;
	std::ifstream fi_cube(("cube/"+basefile+"_clean").c_str());
	
	if(fi_cube.fail()){
                std::cerr<<"file cube open failed"<<std::endl;
                exit(1);
        }
	std::string line_cube;

	srand (time(NULL) ) ;
	sleep (2);  
	
	while(!fi_cube.eof()){//read all the cubes
               getline(fi_cube, line_cube);
               cube_orig.push_back(cube_pair(line_cube, false));
        }
	cube_orig.erase(cube_orig.end());//delete EOF from list
	
	for(unsigned i=0; i<ckt.outputs.size(); i++)//separate cube list for each logic cone
                cube_new[i]=cube_orig;
	std::vector<std::string> cam;
	init_cam(cam, cube_orig.size());//init content addressable memory

	ckt_n::nodelist_t and_list_old;
	init_andlist(not_list, and_list, cube_orig);//create AND tree for each cube
	//create dummy XOR gate to initialize with constant ZERO output, feed it to the BIGOR gate
	std::string name = "zero";
	std::string func = "XOR";
	node_t* dummy_gate = node_t::create_gate(name, func);
	dummy_gate->add_input(ckt.inputs[0]);
	dummy_gate->add_input(ckt.inputs[0]);
	ckt.add_gate(dummy_gate);
	ckt.inputs[0]->add_fanout(dummy_gate);

	ckt_n::ckt_t::node_map_t ckt_nm;
	
	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ main for loop 	
	int i = rand()%ckt.outputs.size();
		//All signals for cubes must be OR before XOR with output
		std::ostringstream convert;
		convert<<i;
		name = "BigOR"+convert.str();
		func = "OR";
		node_t* or_gate = node_t::create_gate(name, func);
		ckt.add_gate(or_gate);
		or_gate->add_input(dummy_gate);
		or_gate->add_input(dummy_gate);
		dummy_gate->add_fanout(or_gate);
		node_t* op = ckt.outputs[i];
		name = op->name;
		op->output = false;
		ckt.outputs.erase(ckt.outputs.begin()+i);
		
		//create the XOR gate
		func = "XOR";
		node_t* xor_gate = node_t::create_gate(name, func);
		xor_gate->output = true;
		ckt.add_gate(xor_gate);
	
		ckt.outputs.insert(ckt.outputs.begin()+i, xor_gate);	
		
		//new output is XOR, original output is old
		op->name += "_old";
		or_gate->add_fanout(xor_gate);
		op->add_fanout(xor_gate);
		xor_gate->add_input(op);
		xor_gate->add_input(or_gate);

		//generate a random solution
		init_sol(or_gate, cube_new[i], true);
		ckt.topo_sort();
		ckt.cleanup();
		store_sol("temp/"+basefile+".bench");
		
		for(unsigned c=0;c<cube_new[i].size();c++){
                        if(cube_new[i][c].second)
                                cam[c][i]='1';
                        else    cam[c][i]='0';
                }
		print_cam_to_file(cam, cube_new[i]);
	
	print_cam_to_file(cam, cube_orig);
	//lock_ckt(cube_orig, cam);
	store_sol("temp/"+basefile+".bench");
	//int cost = compute_cost(basefile, false);
	//std::cout<<"final cost="<<cost<<std::endl;

    }

 ///             %%%%%%%%%%% SFLL %%%%%%%%% main  
    void toc13enc_t::sfll(std::string filename){
	std::vector<cube_pair> cube_orig, cube_new[1000], cube_old[1000];
	std::string orig_benchname;
	for(int i=0; filename[i]!='.';i++)
		orig_benchname+=filename[i];
	basefile=filename;
	std::ifstream fi_cube(("cube/"+basefile+"_clean").c_str());
	
	if(fi_cube.fail()){
                std::cerr<<"file cube open failed"<<std::endl;
                exit(1);
        }
	std::string line_cube;

	srand (time(NULL) ) ;
	sleep (2);  
	
	while(!fi_cube.eof()){//read all the cubes
               getline(fi_cube, line_cube);
               cube_orig.push_back(cube_pair(line_cube, false));
        }
	cube_orig.erase(cube_orig.end());//delete EOF from list
	
	for(unsigned i=0; i<ckt.outputs.size(); i++)//separate cube list for each logic cone
                cube_new[i]=cube_orig;
	std::vector<std::string> cam;
	init_cam(cam, cube_orig.size());//init content addressable memory

	int init_cost = compute_cost(orig_benchname, true);//compute the original cost
	std::cout<<"init cost="<<init_cost<<std::endl;
        //std::cout<<"SFLL"<<std::endl;
	ckt_n::nodelist_t and_list_old;
	init_andlist(not_list, and_list, cube_orig);//create AND tree for each cube
	//create dummy XOR gate to initialize with constant ZERO output, feed it to the BIGOR gate
	std::string name = "zero";
	std::string func = "XOR";
	node_t* dummy_gate = node_t::create_gate(name, func);
	dummy_gate->add_input(ckt.inputs[0]);
	dummy_gate->add_input(ckt.inputs[0]);
	ckt.add_gate(dummy_gate);
	ckt.inputs[0]->add_fanout(dummy_gate);
	int old_cost=0, new_cost=0;

	ckt_n::ckt_t::node_map_t ckt_nm;
	
	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ main for loop 	
	//for(unsigned i=0; i<1;i++){
	for(unsigned i=0; i<ckt.outputs.size();i++){
		//declaration of SA parameters
		//double T=1.0, T_min=0.00001, alpha=0.9;
		//All signals for cubes must be OR before XOR with output
		std::ostringstream convert;
		convert<<i;
		std::string name = "BigOR"+convert.str();
		std::string func = "OR";
		node_t* or_gate = node_t::create_gate(name, func);
		ckt.add_gate(or_gate);
		or_gate->add_input(dummy_gate);
		or_gate->add_input(dummy_gate);
		dummy_gate->add_fanout(or_gate);
		node_t* op = ckt.outputs[i];
		name = op->name;
		op->output = false;
		ckt.outputs.erase(ckt.outputs.begin()+i);
		
		//create the XOR gate
		func = "XOR";
		node_t* xor_gate = node_t::create_gate(name, func);
		xor_gate->output = true;
		ckt.add_gate(xor_gate);
	
		ckt.outputs.insert(ckt.outputs.begin()+i, xor_gate);	
		
		//new output is XOR, original output is old
		op->name += "_old";
		or_gate->add_fanout(xor_gate);
		op->add_fanout(xor_gate);
		xor_gate->add_input(op);
		xor_gate->add_input(or_gate);

		//generate a random solution
		init_sol(or_gate, cube_new[i], false);
		ckt.topo_sort();
		ckt.cleanup();
		//store_sol("temp/"+basefile+".bench");
		//store_rand_sol("temp/"+basefile+"_rand.bench");
		//old_cost = compute_cost(basefile, false);
		
		//goto CAM;
	
		//start SA for optimization
		//ORIGINAL ONE
		/*while(T>T_min){
			for(int sa_ctr=0; sa_ctr<1; sa_ctr++){
				cube_old[i].clear();
				cube_old[i]=cube_new[i];
				index_pair my_pair=neighbor(or_gate, cube_new[i]);
				store_sol("temp/"+basefile+".bench");
				new_cost = compute_cost(basefile, false);
				if(new_cost>=old_cost){
                                        if((double)rand()/RAND_MAX<pow(2.71828, (old_cost-new_cost)/(    T))){//accept randomly
                                                old_cost=new_cost;
                                        }
                                        else{//restore old files
                                                cube_new[i].clear();
                                                cube_new[i]=cube_old[i];
						//std::cout<<"restore"<<std::endl;
						if(my_pair.second){
							exclude_cube(or_gate, and_list[my_pair.first], cube_new[i][my_pair.first]);
						}
						else{
							include_cube(or_gate, and_list[my_pair.first], cube_new[i][my_pair.first]);
						}
                                        }
                                }
                                else{//update new solution
                                        old_cost = new_cost;
                                }
			}//for sa_ctr
			T=T*alpha;
			std::cout<< "TEMP: "<< T<<", cost="<<old_cost<<std::endl;
		}//while T*/
		ckt.topo_sort();
		ckt.cleanup();
		
		//update the cam
		//CAM:for(unsigned c=0;c<cube_new[i].size();c++){
		for(unsigned c=0;c<cube_new[i].size();c++){
                        if(cube_new[i][c].second)
                                cam[c][i]='1';
                        else    cam[c][i]='0';
                }
		print_cam_to_file(cam, cube_new[i]);
		//std::cout<<"Intermediate overhead="<<((double)(old_cost-init_cost)/(double)init_cost)*100<<"%, intermediate cost="<<old_cost<<std::endl;
	}//for i
	
	//is_excludable(cube_new[0][0]);
	store_sol("temp/"+basefile+".bench");
	//exit(0);
	store_sol("temp/"+basefile+"_rand.bench");
	old_cost = compute_cost(basefile, false);

	std::cout<<"Random overhead="<<((double)(old_cost-init_cost)/(double)init_cost)*100<<"%, Random cost="<<old_cost<<std::endl;
	//exit(0);
	double T=1.0, T_min=0.00001, alpha=0.9;
	//exit(0);
	while(T>T_min){
		for(int sa_ctr=0; sa_ctr<100; sa_ctr++){
			int i = rand()%ckt.outputs.size();
			std::ostringstream convert;
			convert<<i;
			std::string or_name = "BigOR"+convert.str();
			node_t* or_gate = get_by_name(ckt.gates, or_name);
			//std::cout<<or_gate->name<<std::endl;
			cube_old[i].clear();
			cube_old[i]=cube_new[i];
			index_pair my_pair=neighbor(or_gate, cube_new[i], cube_new);
			//std::cout<<"neighbor generated"<<std::endl;
			store_sol("temp/"+basefile+".bench");
			new_cost = compute_cost(basefile, false);
			if(new_cost>=old_cost){
                                if((double)rand()/RAND_MAX<pow(2.71828, (old_cost-new_cost)/(T))){//accept randomly
					  //std::cout<<"randomly accepted"<<std::endl;
                                          old_cost=new_cost;
                                }
                                else{//restore old files
                                        //cube_new[i].clear();
                                        //cube_new[i]=cube_old[i];
					//std::cout<<"restore"<<std::endl;
					if(1==my_pair.second){
						exclude_cube(or_gate, and_list[my_pair.first], cube_new[i][my_pair.first]);
					}
					else if(0==my_pair.second){
						include_cube(or_gate, and_list[my_pair.first], cube_new[i][my_pair.first]);
					}
                                }
                       }
                       else{//update new solution
                                old_cost = new_cost;
                       }
			//exit(0);
		}//for sa_ctr
		T=T*alpha;
		std::cout<< "TEMP: "<< T<<", cost="<<old_cost<<std::endl;
		//if(old_cost==init_cost)
			//break;
	}//while T
	ckt.topo_sort();
	ckt.cleanup();
	
	//update the cam
	//CODE HERE
	for(unsigned i=0; i<ckt.outputs.size();i++){
		for(unsigned c=0;c<cube_new[i].size();c++){
                        if(cube_new[i][c].second)
                                cam[c][i]='1';
                        else    cam[c][i]='0';
                }
	}
	//print_cam_to_file(cam, cube_orig);
	for(unsigned i=0; i<ckt.outputs.size();i++)
		print_cam_to_file(cam, cube_new[i]);
	//lock_ckt(cube_orig, cam);
	store_sol("temp/"+basefile+"_final.bench");
	//std::cout<<"final cost="<<old_cost<<std::endl;
	std::cout<<"Final overhead="<<((double)(old_cost-init_cost)/(double)init_cost)*100<<"%, Final cost="<<old_cost<<std::endl;

    }

  bool toc13enc_t::is_excludable(int i, std::vector<cube_pair> cube_all[]){
	//std::cout<<"is_excludable started"<<std::endl;
	int count = 0;
	for(unsigned j=0; j<ckt.outputs.size(); j++){
		if(cube_all[j][i].second)
			count++;
		//std::cout<<"is_excludable loop"<<std::endl;
	}
	//std::cout<<count<<std::endl;
	//std::cout<<"is_excludable done"<<std::endl;
	if(count>1)
		return true;
	else return false;
  }
  
  void toc13enc_t::init_andlist(ckt_n::nodelist_t &not_list, ckt_n::nodelist_t &and_list, std::vector<cube_pair> cube_orig){
	
	node_t* not_gate;

	//create a list of not gates
	for(unsigned j=0; j<ckt.inputs.size(); j++){
			std::string name = "not_"+ckt.inputs[j]->name;
			std::string func = "NOT";
			not_gate = node_t::create_gate(name, func);
			not_gate->add_input(ckt.inputs[j]);
			not_list.push_back(not_gate);	
	}	 

	//create a list of and gates
	for(unsigned j=0; j<cube_orig.size(); j++){
		std::ostringstream convert;
	        convert<<j;
		std::string name = "BigAND"+convert.str();
		std::string func = "AND";
		node_t* and_gate = node_t::create_gate(name, func);
		node_t* not_gate;
		for(unsigned i=0; i< ckt.inputs.size();i++){
			if(cube_orig[j].first[i]=='0'){
				not_gate = not_list [i] ; 
				and_gate->add_input(not_gate);
			}
			else if(cube_orig[j].first[i]=='1'){
				and_gate->add_input(ckt.inputs[i]);
			}
		}
		and_list.push_back(and_gate);	
	}
  }
  void toc13enc_t::store_sol (std::string fname) {
	std::ofstream fout (fname.c_str());
        fout << "### key=" << key_values << std::endl;
	fout << ckt << std::endl;  
    }   
    void toc13enc_t::init_sol(ckt_n::node_t *or_gate, std::vector<cube_pair> &cube_orig, bool is_ttlock){
	
	for(unsigned i=0; i<cube_orig.size(); i++){
		if(rand()%2||is_ttlock){
		//if(rand()%2){
			//std::cout<<i<<" included"<<std::endl;
			include_cube(or_gate, and_list[i], cube_orig[i]);
		}
	}

    }

    node_t* toc13enc_t::init_BigAND(cube_pair &cube_orig, int i){
	std::ostringstream convert;
        convert<<i;
	std::string name = "BigAND"+convert.str();
	std::string func = "AND";
	node_t* and_gate = node_t::create_gate(name, func);
	ckt.add_gate(and_gate);
	for(unsigned j=0; j<ckt.inputs.size();j++){
		if(cube_orig.first[j]=='0'){
			node_t* not_gate;
			std::string name = "not_"+ckt.inputs[j]->name;
			std::string func = "NOT";
			not_gate = node_t::create_gate(name, func);
			not_gate->add_input(ckt.inputs[j]);
			ckt.add_gate(not_gate);
			ckt.inputs[j]->add_fanout(not_gate);
			and_gate->add_input(not_gate);
			not_gate->add_fanout(and_gate);
		}
		else if(cube_orig.first[j]=='1'){
			and_gate->add_input(ckt.inputs[i]);
			ckt.inputs[i]->add_fanout(and_gate);
		}
	}
	int index=find_index(ckt.gates, and_gate);
	assert(index!=1);
	return ckt.gates[index];
    	
    }
    
    void toc13enc_t::add_notlist(){
	for(unsigned i=0;i<ckt.inputs.size();i++){
		if(-1==find_index(ckt.gates, not_list[i])){
			node_t* not_gate=not_list[i];
			ckt.inputs[i]->add_fanout(not_gate);
			ckt.add_gate(not_gate);
		}
	}
    }
    void toc13enc_t::include_cube(node_t* or_gate, node_t* and_gate, cube_pair &cube_orig)
    {	
			add_notlist();
			if(-1==find_index(ckt.gates, and_gate)){
				for(unsigned i=0;i<ckt.inputs.size();i++){
					if(cube_orig.first[i]=='0')
						not_list[i]->add_fanout(and_gate);
					else if(cube_orig.first[i]=='1')
						ckt.inputs[i]->add_fanout(and_gate);
				}
				ckt.add_gate(and_gate);
			}
			or_gate->add_input(and_gate);
			and_gate->add_fanout(or_gate);
			cube_orig.second = true;
    }
    
    void toc13enc_t::exclude_cube(node_t* or_gate, node_t* and_gate, cube_pair &cube_orig)
    {	
			int index=find_index(or_gate->inputs, and_gate);
			assert (index != -1); 
			or_gate->inputs.erase(or_gate->inputs.begin()+index);
			index=find_index(and_gate->fanouts, or_gate);
			and_gate->fanouts.erase(and_gate->fanouts.begin()+index);
			cube_orig.second = false;
    }
    int toc13enc_t::find_index(ckt_n::nodelist_t list, node_t *n){
	for(unsigned i=0; i<list.size();i++)
		if(list[i]->name == n->name)
			return i;
	return -1;	
   } 
   node_t* toc13enc_t::get_by_name(ckt_n::nodelist_t list, std::string name){
	for(unsigned i=0; i<list.size();i++)
		if(!(list[i]->name.compare(name)))
			return list[i];
	return NULL;
  }

   toc13enc_t::index_pair toc13enc_t::neighbor(node_t *or_gate, std::vector<cube_pair> &cube_orig, std::vector<cube_pair> cube_all[]){
	//std::cout<<"neighbor started"<<std::endl;
	assert(cube_orig.size()!=0);
	int i=rand()%cube_orig.size();
	index_pair my_pair;
	my_pair.first=i;
	my_pair.second = 2;
	if(!cube_orig[i].second){
		//std::cout<<i<<"included"<<std::endl;
		include_cube(or_gate, and_list[i], cube_orig[i]);	
		my_pair.second=1;
	}
	else{
		//std::cout<<i<<"excluded"<<std::endl;
		/*while(!is_excludable(i, cube_all)){
			i = rand()%cube_orig.size();
			std::cout<<i<<" can not be excluded"<<std::endl;
		}
		std::cout<<i<<" can be excluded"<<std::endl;
		my_pair.first = i;*/
		if(is_excludable(i, cube_all)){
			exclude_cube(or_gate, and_list[i], cube_orig[i]);	
			my_pair.second=0;
		}
		/*else{
			std::cout<<i<<" can not be excluded"<<std::endl;
			my_pair.second = true;
		}*/
	}
	return my_pair;

   }

   int toc13enc_t::compute_cost(std::string filename, bool init){
	std::string cmd;
	if(init)
		//cmd = "../../../../../abc/abc -c \"read_bench bench/"+ filename + ".bench; sweep; strash; refactor; balance; print_stats;\" > temp/"+basefile+".stat";
		cmd = "~/abc -c \"read_bench bench/"+ filename + ".bench; sweep; strash; refactor; balance; print_stats;\" > temp/"+basefile+".stat";
	//else	cmd = "../../../../../abc/abc -c \"read_bench temp/"+ basefile + ".bench; sweep; strash; refactor; balance; print_stats;\" > temp/"+basefile+".stat";
	else	cmd = "~/abc -c \"read_bench temp/"+ basefile + ".bench; sweep; strash; refactor; balance; print_stats;\" > temp/"+basefile+".stat";
	//std::cout<<cmd<<std::endl;
	
	system(cmd.c_str());
	std::ifstream fi_stat(("temp/"+basefile+".stat").c_str());
        if(fi_stat.fail()){
              std::cerr<<"file stat open failed"<<std::endl;
              exit(1);
	}

	std::string word;
        int cost;
	while(!fi_stat.eof()){
                fi_stat>>word;
                if(!word.compare("and")){
                        fi_stat>>word;//reads '='
                        fi_stat>>cost;//reads the and count
                        return cost;
                }

        }
	exit(1);
   }
   void toc13enc_t::init_cam(std::vector<std::string> &cam, int size){
		for(int i=0;i<size;i++){
			std::string temp;
			for(unsigned j=0;j<ckt.outputs.size();j++)
				temp+='-';
			cam.push_back(temp);
		}
	
   }
void toc13enc_t::print_cam_to_file(std::vector<std::string> cam, std::vector<cube_pair> cube_orig){
        std::ofstream fo("temp/"+basefile+".cam");
        for(unsigned i=0;i<cam.size();i++)
                fo<<cube_orig[i].first<<"|"<<cam[i]<<std::endl;
}

void toc13enc_t::print_verilog(){
	std::string cmd = "../../../../../abc/abc -c \"read_bench "+ basefile + ".bench; sweep; write_verilog "+basefile+".v \"";
	system(cmd.c_str());
}

void toc13enc_t::lock_ckt(std::vector<cube_pair> cube_orig, std::vector<std::string> cam){

	for(unsigned i=0;i<cube_orig.size();i++){	
		std::stringstream ss;
		ss<<i;
		node_t* and_gate = node_t::create_gate("rest_AND"+ss.str(), "AND");
		ckt.add_gate(and_gate);
		rest_andlist.push_back(and_gate);	
	
		for(unsigned j=0;j<cube_orig[i].first.size();j++){
		//for(unsigned j=0;j<ckt.inputs.size();j++){
			std::stringstream ss1,ss2;
			ss1<<i;
			ss2<<j;	
			if(cube_orig[i].first[j]!='-'){
            			node_t* ki = ckt.create_key_input();
			        int val = (char)(cube_orig[i].first[j]) - '0';
				//std::cout<<ki->name<<std::endl;
        			key_values.push_back(val ? true : false);
				ki->keyval = val;
				std::cout<<ki->is_keyinput()<<ki->is_input()<<std::endl;
				node_t* xnor_gate = node_t::create_gate("rest_XNOR"+ss1.str()+ss2.str(), "XNOR");
				xnor_gate->add_input(ki);
				xnor_gate->add_input(ckt.inputs[j]);
				xnor_gate->keygate = true;
				ckt.add_gate(xnor_gate);
				xnor_gate->add_fanout(and_gate);
				and_gate->add_input(xnor_gate);
			}
		}
		
	}
	for(unsigned i=0;i<ckt.outputs.size();i++){
		std::stringstream ss;
		ss<<i;
		node_t* dummy_gate = node_t::create_gate("zero"+ss.str(), "XOR");
		dummy_gate->add_input(ckt.inputs[0]);
		dummy_gate->add_input(ckt.inputs[0]);
		ckt.inputs[0]->add_fanout(dummy_gate);
		ckt.add_gate(dummy_gate);
		node_t* or_gate = node_t::create_gate("rest_OR"+ss.str(), "OR");
		or_gate->add_input(dummy_gate);
		or_gate->add_input(dummy_gate);
		dummy_gate->add_fanout(or_gate);
		ckt.add_gate(or_gate);
		for(unsigned j=0;j<cube_orig.size();j++){	
			if(cam[j][i]=='1'){
				or_gate->add_input(rest_andlist[j]);
				rest_andlist[j]->add_fanout(or_gate);	
			}
		}
		std::string name,func;
		node_t* op = ckt.outputs[i];
		name = op->name;
		op->output = false;
		ckt.outputs.erase(ckt.outputs.begin()+i);

		func = "XOR";
		node_t* xor_gate = node_t::create_gate(name, func);
		xor_gate->add_input(or_gate);
		or_gate->add_fanout(xor_gate);
		xor_gate->output = true;
		ckt.add_gate(xor_gate);

		op->name = "pert_"+name;
		xor_gate->add_input(op);
		op->add_fanout(xor_gate);
	
		ckt.outputs.insert(ckt.outputs.begin()+i, xor_gate);
		//std::cout<<"output"<<i<<std::endl;
				
	}
	//ckt.cleanup();
	//ckt.topo_sort();	

}

	void toc13enc_t::_dpaKeySA(long long nSims){
		double T = 1.0;
		double T_min = 0.00001;
		double alpha = 0.9;
		long long old_count = _evaluateRandomVectorWithKey(nSims);
		//std::cout<<"\nfirst count="<<old_count;
		ckt_n::ckt_t::node_map_t ckt_nm;
		int index;

		// yasin
		 
	    while(T>T_min){
		for(long long i=0; i!=50; i++){
			//std::cout<<"\nIter="<<i;
			ckt_nm.clear();
			ckt_old = new ckt_t(ckt, ckt_nm);
			ckt_old->num_all_key = ckt.num_all_key;
			//std::cout<<"\n\nBefore num_all_key="<<ckt_old->num_all_key;
			_replaceKeyGate();
			do{
			    index = rand()%ckt.num_nodes();
			}while(ckt.is_in_keyinput(ckt.nodes[index]));
			node_t* n = ckt.nodes[index];
			node_t* ki = ckt.create_key_input();
			//int val = rand()%2;
			//std::cout<<" selected node->"<<n->name;
			int val = 0;
			key_values.push_back(val?true:false);
			ki->keyval=val;
			ckt.insert_key_gate(n,ki,val);
			ckt.topo_sort();
			ckt.cleanup();
			long long new_count = _evaluateRandomVectorWithKey(nSims);
			if(old_count>=new_count){	
				if(((double)rand()/RAND_MAX)>pow(2.71828, (new_count-old_count)/T)){
					ckt_nm.clear();
					ckt_t ckt(*ckt_old, ckt_nm);
					ckt.num_all_key = ckt_old->num_all_key;
				}
				else old_count = new_count;
			}
			else old_count = new_count;
			//std::cout<<"\n\nAfter num_all_key="<<ckt.num_all_key;
			//std::cout<<"\ncount="<<old_count;	
		}
		T = T*alpha;
	    	//std::cout<<"\tTemp="<<T;
	    }
	    //std::cout<<"\n"<<_evaluateRandomVectorWithKey(nSims);
    }
   
    void toc13enc_t::_replaceKeyGate(){
		node_t* keyrm;
		int index;
		do{	
			index = rand()%ckt.num_gates();
			keyrm = ckt.gates[index];//select the key to be removed
		}while(!keyrm->is_keygate());
		//std::cout<<"\nkey gate name"<<keyrm->name<<"key gate func"<<keyrm->func<<"\n";	
		ckt.remove_keygate(keyrm);
		//ckt.topo_sort();
		//ckt.cleanup();			
    }

/*
    void toc13enc_t::encodeXORs(int index)
    {
        int target_keys = (int) (fraction*ckt.num_nodes() + 0.5);
        //printf("Encode XOR");

        //typedef std::pair<double, int> double_int_pair_t;
        std::set<int> metric_set;
        for(unsigned i=0; i != ckt.num_nodes(); i++) {
            //double_int_pair_t p(faultMetrics[i], i);
            metric_set.insert(i);
        }

        key_values.clear();

        assert(target_keys < (int) ckt.num_nodes());//terminates if fails
        //int cnt,cnt2;
        nodeset_t nodes_to_insert;
        //for(cnt=0; cnt < target_keys; cnt++) {
            // select the node.
            assert(metric_set.size() > 0);
            //auto last = metric_set.rbegin();
            //int index = last->second;
            //int index = rand()%ckt.num_nodes();
	    //else{
	//	for(cnt2=0;cnt2<metric_set.size();cnt2++)
	//		index=cnt2;
	//		if(ckt.nodes[index]->name == "kinput")
	//			continue;
	//	}
            assert(index >= 0 && index < (int) ckt.num_nodes());
            node_t* n = ckt.nodes[index];

            // get rid of this node now.
            //double_int_pair_t p(*last);
            metric_set.erase(index);
            // add to the set.
            nodes_to_insert.insert(n);
        //}
        for(auto it=nodes_to_insert.begin(); it != nodes_to_insert.end(); it++) {
            node_t* n = *it;
            // add the key now.
            node_t* ki = ckt.create_key_input();
            int val = rand() % 2;
            key_values.push_back(val ? true : false);
            ckt.insert_key_gate(n, ki, val);
        }
        ckt.topo_sort();
        ckt.cleanup();
    }
*/
    void toc13enc_t::write(std::ostream& out)
    {
        //printf("Inside write");
        out << "# key=" << key_values << std::endl;
        out << ckt << std::endl;
    }

    long long toc13enc_t::_evaluateRandomVectorWithKey(long long nSims)
    {
	//std::cout<<"\nSim start";	
        ckt_eval_t sim(ckt, ckt.inputs);

        bool_vec_t inputs(ckt.num_inputs());
        bool_vec_t outputs(ckt.num_outputs());
	bool_vec_t inputs_corr(inputs.size());
	bool_vec_t inputs_rand(inputs.size());
	bool_vec_t outputs_corr(outputs.size());
	bool_vec_t outputs_rand(outputs.size());
	int index;
	long long count=0;
	for(unsigned i=0; i!=ckt.key_inputs.size();i++){
		index = ckt.find_index_inputs(ckt.inputs, ckt.key_inputs[i]);
		ckt_keyinp_indices.push_back(index);
	}

	//std::cout<<"\nNumber of key inputs "<<ckt.num_key_inputs()<<"\n";
        for(int i=0; i < nSims; i++) {
	//std::cout<<"\n\n@@@@@@@@@@@@@@@RUN@@@@@@@@@@@@@\n\n";
            for(unsigned j=0; j != inputs.size(); j++)
                inputs[j] = rand()%2;
                //inputs[j] = 0;
	    inputs_corr = inputs;
            for(unsigned j=0; j != ckt.key_inputs.size(); j++){
                inputs_corr[ckt_keyinp_indices[j]] = ckt.key_inputs[j]->keyval;
	    	//std::cout<<ckt.key_inputs[j]->keyval;
	    }
	    //std::cout<<"\n\nCorrect key";
            sim.eval(inputs_corr, outputs_corr);
            input_sims.push_back(inputs_corr);
            output_sims.push_back(outputs_corr);
	    //same input with random key
	    //std::cout<<"\n\nRandom key";
	    inputs_rand = inputs;
	    //std::cout<<"\nOutput size="<<ckt.num_outputs();	
            sim.eval(inputs_rand, outputs_rand);
            input_sims.push_back(inputs_rand);
            output_sims.push_back(outputs_rand);
	    for(unsigned j=0; j != outputs.size(); j++){
		if(outputs_corr[j] == outputs_rand[j])
		    count++;
	    }
        }
        //std::cout<<"\nSim end";	
        return count;
    }

    /*void toc13enc_t::_evaluateRandomVectorSlicewiseWithKey(long long  cktslice_nSims)
    {
	//add input transitive fan_in code
	ckt_n::ckt_t::node_map_t ckt_nmfwd, ckt_nmrev;
	nodelist_t cktOutputs, sortedCktOutputs;
	typedef std::pair<int, node_t*> yasin_pair;
	std::vector<yasin_pair> numOfKeysInSlice;

	//int index;
	//for(unsigned i=0; i!=ckt.key_inputs.size();i++){
	//	index = ckt.find_index_inputs(ckt.inputs, ckt.key_inputs[i]);
	//	ckt_keyinp_indices.push_back(index);
	//}

	for(unsigned i=0;i!=1;i++){
		ckt_nmfwd.clear();
		ckt_nmrev.clear();
		cktOutputs.clear();

		node_t* out_i = ckt.outputs[i];
		cktOutputs.push_back(out_i);
		cktslice = new ckt_t(ckt, cktOutputs, ckt_nmfwd, ckt_nmrev);
		int num_cur_keys = cktslice->key_inputs.size();
		std::cout<<"\n Slice created with "<<cktslice->num_inputs()<<"inputs and"<<num_cur_keys<<"keys in " << i <<"th slice\n";
		}//numOfKeysInSlice.push_back(yasin_pair(num_cur_keys, out_i));*/
	        /*ckt_eval_t sim(*cktslice, cktslice->inputs);
		
        	for(int j=0; j < cktslice_nSims; j++) {
            		bool_vec_t inputs(cktslice->num_inputs());
           		bool_vec_t outputs(cktslice->num_outputs());
	   		//for(unsigned j=0; j<cktslice->ckt_inputs.size();j++){
			//	int index = cktslice->find_index_inputs(cktslice->inputs, cktslice->ckt_inputs[j]);
				//std::cout<<"\n"<<index<<"\n";
			//	slice_cktinp_indices.push_back(index);
	    		//}
				
	    		for(unsigned k=0; k<inputs.size();k++)
				inputs[k]=rand()%2;
			
            		sim.eval(inputs, outputs);//eval() in sim.h
            		input_sims.push_back(inputs);
            		output_sims.push_back(outputs);
        	}*/
	//}
   // }*/	
    /*void toc13enc_t::_evaluateRandomVectorSlicewiseWithKey(bool init)
    {
	//add input transitive closure code
	ckt_n::ckt_t::node_map_t ckt_nmfwd, ckt_nmrev;
	nodelist_t cktOutputs, sortedCktOutputs;
	typedef std::pair<int, node_t*> yasin_pair;
	std::vector<yasin_pair> numOfKeysInSlice;

	//int index;
	for(unsigned i=0; i!=ckt.key_inputs.size();i++){
		index = ckt.find_index_inputs(ckt.inputs, ckt.key_inputs[i]);
		ckt_keyinp_indices.push_back(index);
	}
	if(init){
	init = false;
	for(unsigned i=0;i!=ckt.outputs.size();i++){
		ckt_nmfwd.clear();
		ckt_nmrev.clear();
		cktOutputs.clear();

		node_t* out_i = ckt.outputs[i];
		cktOutputs.push_back(out_i);
		cktslice = new ckt_t(ckt, cktOutputs, ckt_nmfwd, ckt_nmrev);
		int num_cur_keys = cktslice->key_inputs.size();
		std::cout<<"\n Slice created with "<<cktslice->num_inputs()<<"in "<<i<<" th slice\n";
		numOfKeysInSlice.push_back(yasin_pair(num_cur_keys, out_i));
	        ckt_eval_t sim(*cktslice, cktslice->inputs);
		
		long long cktslice_nSims = 1000000;
        	for(int i=0; i < cktslice_nSims; i++) {
            		bool_vec_t inputs(cktslice->num_inputs());
           		bool_vec_t outputs(cktslice->num_outputs());
	   		for(unsigned j=0; j<cktslice->ckt_inputs.size();j++){
				int index = cktslice->find_index_inputs(cktslice->inputs, cktslice->ckt_inputs[j]);
				//std::cout<<"\n"<<index<<"\n";
				slice_cktinp_indices.push_back(index);
	    		}
			
	    		for(unsigned j=0; j<cktslice->key_inputs.size();j++){
				int index = cktslice->find_index_inputs(cktslice->inputs, cktslice->key_inputs[j]);
				//std::cout<<"\n"<<index<<"\n";
				slice_keyinp_indices.push_back(index);
	    		}
			
	    		for(unsigned j=0; j<inputs.size();j++)
				inputs[j]=rand()%2;
			
            		sim.eval(inputs, outputs);//eval() in sim.h
            		input_sims.push_back(inputs);
            		output_sims.push_back(outputs);
        	}
	}
	}*/
	/*
	for(unsigned i=0;i!=ckt.outputs.size();i++){
		ckt_nmfwd.clear();
		ckt_nmrev.clear();
		cktOutputs.clear();

		node_t* out_i = ckt.outputs[i];
		cktOutputs.push_back(out_i);
		cktslice = new ckt_t(ckt, cktOutputs, ckt_nmfwd, ckt_nmrev);
		int num_cur_keys = cktslice->key_inputs.size();
		std::cout<<"\n Slice created with"<<num_cur_keys<<"keys in "<<i<<"slice\n";
		numOfKeysInSlice.push_back(yasin_pair(num_cur_keys, out_i));
	        ckt_eval_t sim(*cktslice, cktslice->inputs);

        	for(int i=0; i < nSims; i++) {
            		bool_vec_t inputs(cktslice->num_inputs());
           		bool_vec_t outputs(cktslice->num_outputs());
	   		for(unsigned j=0; j<cktslice->ckt_inputs.size();j++){
				int index = cktslice->find_index_inputs(cktslice->inputs, cktslice->ckt_inputs[j]);
				//std::cout<<"\n"<<index<<"\n";
				slice_cktinp_indices.push_back(index);
	    		}
			
	    		for(unsigned j=0; j<cktslice->key_inputs.size();j++){
				int index = cktslice->find_index_inputs(cktslice->inputs, cktslice->key_inputs[j]);
				//std::cout<<"\n"<<index<<"\n";
				slice_keyinp_indices.push_back(index);
	    		}
			
	    		for(unsigned j=0; j<inputs.size();j++)
				inputs[j]=rand()%2;
			
            		sim.eval(inputs, outputs);//eval() in sim.h
            		input_sims.push_back(inputs);
            		output_sims.push_back(outputs);
        	}
	}
	*/
	/*
        //ckt_eval_t sim(ckt, ckt.ckt_inputs);
        ckt_eval_t sim(ckt, ckt.inputs);
	//std::cout<<"number of ckt ckt inputs"<<ckt.ckt_inputs.size();
	//std::cout<<"number of ckt key inputs"<<ckt.key_inputs.size();
        //assert(ckt.num_key_inputs() == 0);
        //bool_vec_t inputs(ckt.num_ckt_inputs());
        //bool_vec_t outputs(ckt.num_outputs());
        for(int i=0; i < nSims; i++) {
            bool_vec_t inputs(ckt.num_inputs());
            bool_vec_t outputs(ckt.num_outputs());
	    for(unsigned j=0; j<ckt.ckt_inputs.size();j++){
		int index = ckt.find_index_inputs(ckt.inputs, ckt.ckt_inputs[j]);
		//std::cout<<"\n"<<index<<"\n";
		ckt_cktinp_indices.push_back(index);
	    }
	    for(unsigned j=0; j<ckt.key_inputs.size();j++){
		int index = ckt.find_index_inputs(ckt.inputs, ckt.key_inputs[j]);
		//std::cout<<"\n"<<index<<"\n";
		ckt_keyinp_indices.push_back(index);
	    }
	    for(unsigned j=0; j<inputs.size();j++)
		inputs[j]=rand()%2;
	    key_vector.push_back(0);
	    key_vector.push_back(1);
	    for(unsigned j=0;j<key_vector.size();j++){
		inputs[ckt_keyinp_indices[j]]=(rand()%3)%2;
		std::cout<<"\nkey got assigned\n";	
	    }
	    inputs[ckt_keyinp_indices[0]]=1;
	    inputs[ckt_keyinp_indices[1]]=0;
            sim.eval(inputs, outputs);//eval() in sim.h
            input_sims.push_back(inputs);
            output_sims.push_back(outputs);
        }
	*/
    //}

    void toc13enc_t::_evaluateRandomVectors(int nSims)
    {
        ckt_eval_t sim(ckt, ckt.ckt_inputs);

        //assert(ckt.num_key_inputs() == 0);
        bool_vec_t inputs(ckt.num_ckt_inputs());
        bool_vec_t outputs(ckt.num_outputs());

	//std::cout<<"\nEvaluation of original ckt\n";
        for(int i=0; i < nSims; i++) {
            for(unsigned j=0; j != inputs.size(); j++) {
                inputs[j] = rand()%2;
            }
            sim.eval(inputs, outputs);
            input_sims.push_back(inputs);
            output_sims.push_back(outputs);
        }
    }


    double toc13enc_t::_evaluateFaultImpact(node_t* n)
    {
        //printf("Inside eval fault impact");
        assert(input_sims.size() == output_sims.size());

        using namespace sat_n;

        Solver S;

        nodeset_t n2ignore;
        n2ignore.insert(n);
        index2lit_map_t lmap;
        ckt.init_solver_ignoring_nodes(S, lmap, n2ignore);

        vec_lit_t assumps(ckt.num_inputs() + 1);
        bool_vec_t err_outputs(ckt.num_outputs());

        double metric = 0;
        for(unsigned int i=0; i < input_sims.size(); i++) {
            bool result;

            _set_assumps(assumps, lmap, input_sims[i], n, 0);
            result = S.solve(assumps);
            assert(result);
            _extract_outputs(S, lmap, err_outputs);
            metric += _count_differing_outputs(output_sims[i], err_outputs);

            _set_assumps(assumps, lmap, input_sims[i], n, 1);
            result = S.solve(assumps);
            assert(result);
            _extract_outputs(S, lmap, err_outputs);
            metric += _count_differing_outputs(output_sims[i], err_outputs);
        }
        return metric / input_sims.size();
    }

    void toc13enc_t::_set_assumps(sat_n::vec_lit_t& assumps,
        ckt_n::index2lit_map_t& lmap,
        const bool_vec_t& inputs,
        node_t* n,
        int fault)
    {
        //printf("Inside assump");
        using namespace sat_n;
        assert(assumps.size() == inputs.size()+1);
        assert(inputs.size() == ckt.num_ckt_inputs());
        for(unsigned i=0; i != ckt.num_ckt_inputs(); i++) {
            Lit li = ckt.getLit(lmap, ckt.ckt_inputs[i]);
            if(ckt.ckt_inputs[i] != n) {
                assumps[i] = inputs[i] ? li : ~li;
            } else {
                assumps[i] = fault ? li : ~li;
            }
        }
        int last = ckt.num_ckt_inputs();
        Lit l_node = ckt.getLit(lmap, n);
        assumps[last] = fault ? l_node : ~l_node;
    }

    void toc13enc_t::_extract_outputs(
        sat_n::Solver& S,
        ckt_n::index2lit_map_t& lmap,
        bool_vec_t& outputs
    )
    {
        //printf("Inside extra op");
        using namespace sat_n;

        assert(outputs.size() == ckt.num_outputs());
        for(unsigned i=0; i != ckt.num_outputs(); i++) {
            lbool l_out_i = S.modelValue(ckt.getLit(lmap, ckt.outputs[i]));
            assert(l_out_i.isDef());
            outputs[i] = l_out_i.getBool();
        }
    }
    
    int toc13enc_t::_count_differing_outputs(
        const bool_vec_t& sim_out, const bool_vec_t& err_out)
    {
        //printf("Inside diff op");
        int cnt = 0;
        assert(sim_out.size() == err_out.size());
        for(unsigned i=0; i != sim_out.size(); i++) {
            if(sim_out[i] != err_out[i]) cnt += 1;
        }
        return cnt;
    }
}



// end of the file.
// 
//
//
