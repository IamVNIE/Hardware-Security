#! /bin/sh
rm -rf include *.bak *~
